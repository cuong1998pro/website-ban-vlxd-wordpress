## Đặt tên thư mục là wordpress
### File csdl là file wordpress.sql
